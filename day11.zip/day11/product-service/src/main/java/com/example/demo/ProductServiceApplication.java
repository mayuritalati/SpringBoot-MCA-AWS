package com.example.demo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class ProductServiceApplication {
	

private Logger logger=Logger.getLogger("com.example.demo.ProductServiceApplication");	

@GetMapping("/products")	
public List<String> getNames(){
	logger.info("Product Service getting the product names..."+new Date());
		
	return Arrays.asList("Camera","Mobile","TV");
}	
	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

}
