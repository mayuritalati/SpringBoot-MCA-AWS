package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class HelloController {
	
	
	@Autowired
	private RestTemplate restTemplate;
	
		

	
	
	public HelloController() {
	System.out.println("Hello Controller cretaed...");
	}
	
	
	@GetMapping("/hello")
	public String hello() {
		return "HEllo World!!!";
	}
	
	
	@GetMapping("/rest/users")
	public String users() {
		return restTemplate.getForObject("https://jsonplaceholder.typicode.com/users",String.class);
	}
	
	
	
	
	
	@HystrixCommand(fallbackMethod = "fallback"/*,commandProperties = {
		      @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "1000")
		   }*/)
	
	@GetMapping("/rest/posts")
	public String posts() throws InterruptedException {
		
		
		
		Thread.sleep(2000);
		
		return restTemplate.getForObject("https://jsonplaceholder.typicode.com/posts",String.class);
	}
	
	
	public String fallback() {
		return "This site is temporarily down Try after some time";
	}
	
	
	
}
