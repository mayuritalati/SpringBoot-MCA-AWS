package com.example.demo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@Configuration
@RestController
@SpringBootApplication
public class CustomerServiceApplication {

private Logger logger=Logger.getLogger("com.example.demo.CustomerServiceApplication");	
	
@Autowired	
private RestTemplate restTemplate;	
	
	

@Bean
public RestTemplate getRestTemplate() {
	
	return new RestTemplate();
}


@GetMapping("/customers")	
public List<String> getNames(){

	logger.info("getting the customer names..."+new Date());
	
	
	return Arrays.asList("RAM","RAHIM","DAVID");
}	
	
	


@GetMapping("/customers/products")	
public String getProductNames(){
	logger.info("getting the product names..."+new Date());
	
	return  restTemplate.getForObject("http://localhost:2222/products",String.class);
}	
	
	public static void main(String[] args) {
		SpringApplication.run(CustomerServiceApplication.class, args);
	}

}
