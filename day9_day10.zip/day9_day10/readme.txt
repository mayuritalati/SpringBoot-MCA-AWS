admin-server
eureka-server
hello
welcome
greet
zuulproxy