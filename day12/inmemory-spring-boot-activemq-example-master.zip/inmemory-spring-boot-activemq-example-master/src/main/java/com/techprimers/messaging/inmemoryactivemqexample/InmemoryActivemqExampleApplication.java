package com.techprimers.messaging.inmemoryactivemqexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InmemoryActivemqExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(InmemoryActivemqExampleApplication.class, args);
	}
}
