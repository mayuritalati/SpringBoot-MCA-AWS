# Spring Boot Application accessing Standalone ActiveMQ
